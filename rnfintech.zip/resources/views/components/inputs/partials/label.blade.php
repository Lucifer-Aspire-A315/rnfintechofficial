<label class="{{ ($required ?? false) ? 'label label-required font-medium text-gray-700' : 'label font-medium text-gray-700' }}" for="{{ $name }}">
    {{ $label }}
</label>