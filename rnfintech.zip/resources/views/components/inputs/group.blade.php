<div {{ $attributes->merge(['class' => 'px-4 my-2']) }}>
    {{ $slot }}
</div>