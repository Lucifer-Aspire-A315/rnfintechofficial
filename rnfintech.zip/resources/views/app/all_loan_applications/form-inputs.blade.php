@php $editing = isset($loanApplications) @endphp

<div class="flex flex-wrap">
    <x-inputs.group class="w-full">
        <x-inputs.select name="user_id" label="User" required>
            @php $selected = old('user_id', ($editing ? $loanApplications->user_id : '')) @endphp
            <option disabled {{ empty($selected) ? 'selected' : '' }}>Please select the User</option>
            @foreach($users as $value => $label)
            <option value="{{ $value }}" {{ $selected == $value ? 'selected' : '' }} >{{ $label }}</option>
            @endforeach
        </x-inputs.select>
    </x-inputs.group>

    <x-inputs.group class="w-full">
        <x-inputs.text
            name="name_of_applicant"
            label="Name Of Applicant"
            :value="old('name_of_applicant', ($editing ? $loanApplications->name_of_applicant : ''))"
            maxlength="255"
            placeholder="Name Of Applicant"
            required
        ></x-inputs.text>
    </x-inputs.group>

    <x-inputs.group class="w-full">
        <x-inputs.text
            name="phone"
            label="Phone"
            :value="old('phone', ($editing ? $loanApplications->phone : ''))"
            placeholder="Phone"
            required
        ></x-inputs.text>
    </x-inputs.group>

    <x-inputs.group class="w-full">
        <x-inputs.number
            name="amount"
            label="Amount"
            :value="old('amount', ($editing ? $loanApplications->amount : ''))"
            step="1"
            placeholder="Amount"
            required
        ></x-inputs.number>
    </x-inputs.group>

    <x-inputs.group class="w-full lg:w-6/12">
        <x-inputs.text
            name="pan_number"
            label="Pan Number"
            :value="old('pan_number', ($editing ? $loanApplications->pan_number : ''))"
            maxlength="255"
            placeholder="Pan Number"
            required
        ></x-inputs.text>
    </x-inputs.group>

    <x-inputs.group class="w-full lg:w-6/12">
        <x-inputs.partials.label
            name="pan_image"
            label="PanCard Image"
        ></x-inputs.partials.label
        ><br />

        <input
            type="file"
            name="pan_image"
            id="pan_image"
            class="form-control-file"
        />

        @if($editing && $loanApplications->pan_image)
        <div class="mt-2">
            <a
                href="{{ \Storage::url($loanApplications->pan_image) }}"
                target="_blank"
                ><i class="icon ion-md-download"></i>&nbsp;Download</a
            >
        </div>
        @endif @error('pan_image') @include('components.inputs.partials.error')
        @enderror
    </x-inputs.group>

    <x-inputs.group class="w-full lg:w-6/12">
        <x-inputs.text
            name="adhar_number"
            label="Adhar Number"
            :value="old('adhar_number', ($editing ? $loanApplications->adhar_number : ''))"
            maxlength="255"
            placeholder="Adhar Number"
            required
        ></x-inputs.text>
    </x-inputs.group>

    <x-inputs.group class="w-full lg:w-6/12">
        <x-inputs.partials.label
            name="adhar_image"
            label="AdharCard Image"
        ></x-inputs.partials.label
        ><br />

        <input
            type="file"
            name="adhar_image"
            id="adhar_image"
            class="form-control-file"
        />

        @if($editing && $loanApplications->adhar_image)
        <div class="mt-2">
            <a
                href="{{ \Storage::url($loanApplications->adhar_image) }}"
                target="_blank"
                ><i class="icon ion-md-download"></i>&nbsp;Download</a
            >
        </div>
        @endif @error('adhar_image')
        @include('components.inputs.partials.error') @enderror
    </x-inputs.group>

    <x-inputs.group class="w-full">
        <x-inputs.text
            name="pincode"
            label="Pincode"
            :value="old('pincode', ($editing ? $loanApplications->pincode : ''))"
            placeholder="Pincode"
            required
        ></x-inputs.text>
    </x-inputs.group>

    <x-inputs.group class="w-full">
        <x-inputs.select name="status" label="Status">
            @php $selected = old('status', ($editing ? $loanApplications->status : '')) @endphp
            <option value="pending" {{ $selected == 'pending' ? 'selected' : '' }} >Pending</option>
            <option value="inreview" {{ $selected == 'inreview' ? 'selected' : '' }} >Inreview</option>
            <option value="completed" {{ $selected == 'completed' ? 'selected' : '' }} >Completed</option>
            <option value="rejected" {{ $selected == 'rejected' ? 'selected' : '' }} >Rejected</option>
        </x-inputs.select>
    </x-inputs.group>

    <x-inputs.group class="w-full lg:w-6/12">
        <x-inputs.select name="loan_type_id" label="Loan Type" required>
            @php $selected = old('loan_type_id', ($editing ? $loanApplications->loan_type_id : '')) @endphp
            <option disabled {{ empty($selected) ? 'selected' : '' }}>Please select the Loan Type</option>
            @foreach($loanTypes as $value => $label)
            <option value="{{ $value }}" {{ $selected == $value ? 'selected' : '' }} >{{ $label }}</option>
            @endforeach
        </x-inputs.select>
    </x-inputs.group>

    <x-inputs.group class="w-full lg:w-6/12">
        <x-inputs.select name="bank_id" label="Bank" required>
            @php $selected = old('bank_id', ($editing ? $loanApplications->bank_id : '')) @endphp
            <option disabled {{ empty($selected) ? 'selected' : '' }}>Please select the Bank</option>
            @foreach($banks as $value => $label)
            <option value="{{ $value }}" {{ $selected == $value ? 'selected' : '' }} >{{ $label }}</option>
            @endforeach
        </x-inputs.select>
    </x-inputs.group>

    <x-inputs.group class="w-full">
        <x-inputs.text
            name="reason_of_rejection"
            label="Reason Of Rejection"
            :value="old('reason_of_rejection', ($editing ? $loanApplications->reason_of_rejection : ''))"
            placeholder="Leave it empty while file new loan application"
        ></x-inputs.text>
    </x-inputs.group>
</div>
