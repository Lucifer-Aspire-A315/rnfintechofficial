<?php $editing = isset($loanApplications) ?>

<div class="flex flex-wrap">
    <?php if (isset($component)) { $__componentOriginalcd518abb053461cdf447c22dc90a5514 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd518abb053461cdf447c22dc90a5514 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.group','data' => ['class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full']); ?>
        <?php if (isset($component)) { $__componentOriginal4e150f034db9bd45fe1495cb5234d541 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4e150f034db9bd45fe1495cb5234d541 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.select','data' => ['name' => 'user_id','label' => 'User','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'user_id','label' => 'User','required' => true]); ?>
            <?php $selected = old('user_id', ($editing ? $loanApplications->user_id : '')) ?>
            <option disabled <?php echo e(empty($selected) ? 'selected' : ''); ?>>Please select the User</option>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value); ?>" <?php echo e($selected == $value ? 'selected' : ''); ?> ><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4e150f034db9bd45fe1495cb5234d541)): ?>
<?php $attributes = $__attributesOriginal4e150f034db9bd45fe1495cb5234d541; ?>
<?php unset($__attributesOriginal4e150f034db9bd45fe1495cb5234d541); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4e150f034db9bd45fe1495cb5234d541)): ?>
<?php $component = $__componentOriginal4e150f034db9bd45fe1495cb5234d541; ?>
<?php unset($__componentOriginal4e150f034db9bd45fe1495cb5234d541); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $attributes = $__attributesOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__attributesOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $component = $__componentOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__componentOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalcd518abb053461cdf447c22dc90a5514 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd518abb053461cdf447c22dc90a5514 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.group','data' => ['class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full']); ?>
        <?php if (isset($component)) { $__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.text','data' => ['name' => 'name_of_applicant','label' => 'Name Of Applicant','value' => old('name_of_applicant', ($editing ? $loanApplications->name_of_applicant : '')),'maxlength' => '255','placeholder' => 'Name Of Applicant','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'name_of_applicant','label' => 'Name Of Applicant','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('name_of_applicant', ($editing ? $loanApplications->name_of_applicant : ''))),'maxlength' => '255','placeholder' => 'Name Of Applicant','required' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47)): ?>
<?php $attributes = $__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47; ?>
<?php unset($__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47)): ?>
<?php $component = $__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47; ?>
<?php unset($__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $attributes = $__attributesOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__attributesOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $component = $__componentOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__componentOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalcd518abb053461cdf447c22dc90a5514 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd518abb053461cdf447c22dc90a5514 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.group','data' => ['class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full']); ?>
        <?php if (isset($component)) { $__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.text','data' => ['name' => 'phone','label' => 'Phone','value' => old('phone', ($editing ? $loanApplications->phone : '')),'placeholder' => 'Phone','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'phone','label' => 'Phone','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('phone', ($editing ? $loanApplications->phone : ''))),'placeholder' => 'Phone','required' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47)): ?>
<?php $attributes = $__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47; ?>
<?php unset($__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47)): ?>
<?php $component = $__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47; ?>
<?php unset($__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $attributes = $__attributesOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__attributesOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $component = $__componentOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__componentOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalcd518abb053461cdf447c22dc90a5514 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd518abb053461cdf447c22dc90a5514 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.group','data' => ['class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full']); ?>
        <?php if (isset($component)) { $__componentOriginale684c8dda78a64e4fa641bc96f77cfd2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale684c8dda78a64e4fa641bc96f77cfd2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.number','data' => ['name' => 'amount','label' => 'Amount','value' => old('amount', ($editing ? $loanApplications->amount : '')),'step' => '1','placeholder' => 'Amount','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'amount','label' => 'Amount','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('amount', ($editing ? $loanApplications->amount : ''))),'step' => '1','placeholder' => 'Amount','required' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale684c8dda78a64e4fa641bc96f77cfd2)): ?>
<?php $attributes = $__attributesOriginale684c8dda78a64e4fa641bc96f77cfd2; ?>
<?php unset($__attributesOriginale684c8dda78a64e4fa641bc96f77cfd2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale684c8dda78a64e4fa641bc96f77cfd2)): ?>
<?php $component = $__componentOriginale684c8dda78a64e4fa641bc96f77cfd2; ?>
<?php unset($__componentOriginale684c8dda78a64e4fa641bc96f77cfd2); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $attributes = $__attributesOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__attributesOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $component = $__componentOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__componentOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalcd518abb053461cdf447c22dc90a5514 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd518abb053461cdf447c22dc90a5514 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.group','data' => ['class' => 'w-full lg:w-6/12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full lg:w-6/12']); ?>
        <?php if (isset($component)) { $__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.text','data' => ['name' => 'pan_number','label' => 'Pan Number','value' => old('pan_number', ($editing ? $loanApplications->pan_number : '')),'maxlength' => '255','placeholder' => 'Pan Number','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'pan_number','label' => 'Pan Number','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('pan_number', ($editing ? $loanApplications->pan_number : ''))),'maxlength' => '255','placeholder' => 'Pan Number','required' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47)): ?>
<?php $attributes = $__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47; ?>
<?php unset($__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47)): ?>
<?php $component = $__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47; ?>
<?php unset($__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $attributes = $__attributesOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__attributesOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $component = $__componentOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__componentOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalcd518abb053461cdf447c22dc90a5514 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd518abb053461cdf447c22dc90a5514 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.group','data' => ['class' => 'w-full lg:w-6/12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full lg:w-6/12']); ?>
        <?php if (isset($component)) { $__componentOriginal5067e5c8c802875d7df4971082ac1d85 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5067e5c8c802875d7df4971082ac1d85 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.partials.label','data' => ['name' => 'pan_image','label' => 'PanCard Image']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.partials.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'pan_image','label' => 'PanCard Image']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5067e5c8c802875d7df4971082ac1d85)): ?>
<?php $attributes = $__attributesOriginal5067e5c8c802875d7df4971082ac1d85; ?>
<?php unset($__attributesOriginal5067e5c8c802875d7df4971082ac1d85); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5067e5c8c802875d7df4971082ac1d85)): ?>
<?php $component = $__componentOriginal5067e5c8c802875d7df4971082ac1d85; ?>
<?php unset($__componentOriginal5067e5c8c802875d7df4971082ac1d85); ?>
<?php endif; ?><br />

        <input
            type="file"
            name="pan_image"
            id="pan_image"
            class="form-control-file"
        />

        <?php if($editing && $loanApplications->pan_image): ?>
        <div class="mt-2">
            <a
                href="<?php echo e(\Storage::url($loanApplications->pan_image)); ?>"
                target="_blank"
                ><i class="icon ion-md-download"></i>&nbsp;Download</a
            >
        </div>
        <?php endif; ?> <?php $__errorArgs = ['pan_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo $__env->make('components.inputs.partials.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $attributes = $__attributesOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__attributesOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $component = $__componentOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__componentOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalcd518abb053461cdf447c22dc90a5514 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd518abb053461cdf447c22dc90a5514 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.group','data' => ['class' => 'w-full lg:w-6/12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full lg:w-6/12']); ?>
        <?php if (isset($component)) { $__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.text','data' => ['name' => 'adhar_number','label' => 'Adhar Number','value' => old('adhar_number', ($editing ? $loanApplications->adhar_number : '')),'maxlength' => '255','placeholder' => 'Adhar Number','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'adhar_number','label' => 'Adhar Number','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('adhar_number', ($editing ? $loanApplications->adhar_number : ''))),'maxlength' => '255','placeholder' => 'Adhar Number','required' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47)): ?>
<?php $attributes = $__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47; ?>
<?php unset($__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47)): ?>
<?php $component = $__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47; ?>
<?php unset($__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $attributes = $__attributesOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__attributesOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $component = $__componentOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__componentOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalcd518abb053461cdf447c22dc90a5514 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd518abb053461cdf447c22dc90a5514 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.group','data' => ['class' => 'w-full lg:w-6/12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full lg:w-6/12']); ?>
        <?php if (isset($component)) { $__componentOriginal5067e5c8c802875d7df4971082ac1d85 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5067e5c8c802875d7df4971082ac1d85 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.partials.label','data' => ['name' => 'adhar_image','label' => 'AdharCard Image']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.partials.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'adhar_image','label' => 'AdharCard Image']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5067e5c8c802875d7df4971082ac1d85)): ?>
<?php $attributes = $__attributesOriginal5067e5c8c802875d7df4971082ac1d85; ?>
<?php unset($__attributesOriginal5067e5c8c802875d7df4971082ac1d85); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5067e5c8c802875d7df4971082ac1d85)): ?>
<?php $component = $__componentOriginal5067e5c8c802875d7df4971082ac1d85; ?>
<?php unset($__componentOriginal5067e5c8c802875d7df4971082ac1d85); ?>
<?php endif; ?><br />

        <input
            type="file"
            name="adhar_image"
            id="adhar_image"
            class="form-control-file"
        />

        <?php if($editing && $loanApplications->adhar_image): ?>
        <div class="mt-2">
            <a
                href="<?php echo e(\Storage::url($loanApplications->adhar_image)); ?>"
                target="_blank"
                ><i class="icon ion-md-download"></i>&nbsp;Download</a
            >
        </div>
        <?php endif; ?> <?php $__errorArgs = ['adhar_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <?php echo $__env->make('components.inputs.partials.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $attributes = $__attributesOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__attributesOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $component = $__componentOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__componentOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalcd518abb053461cdf447c22dc90a5514 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd518abb053461cdf447c22dc90a5514 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.group','data' => ['class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full']); ?>
        <?php if (isset($component)) { $__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.text','data' => ['name' => 'pincode','label' => 'Pincode','value' => old('pincode', ($editing ? $loanApplications->pincode : '')),'placeholder' => 'Pincode','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'pincode','label' => 'Pincode','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('pincode', ($editing ? $loanApplications->pincode : ''))),'placeholder' => 'Pincode','required' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47)): ?>
<?php $attributes = $__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47; ?>
<?php unset($__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47)): ?>
<?php $component = $__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47; ?>
<?php unset($__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $attributes = $__attributesOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__attributesOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $component = $__componentOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__componentOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalcd518abb053461cdf447c22dc90a5514 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd518abb053461cdf447c22dc90a5514 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.group','data' => ['class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full']); ?>
        <?php if (isset($component)) { $__componentOriginal4e150f034db9bd45fe1495cb5234d541 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4e150f034db9bd45fe1495cb5234d541 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.select','data' => ['name' => 'status','label' => 'Status']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'status','label' => 'Status']); ?>
            <?php $selected = old('status', ($editing ? $loanApplications->status : '')) ?>
            <option value="pending" <?php echo e($selected == 'pending' ? 'selected' : ''); ?> >Pending</option>
            <option value="inreview" <?php echo e($selected == 'inreview' ? 'selected' : ''); ?> >Inreview</option>
            <option value="completed" <?php echo e($selected == 'completed' ? 'selected' : ''); ?> >Completed</option>
            <option value="rejected" <?php echo e($selected == 'rejected' ? 'selected' : ''); ?> >Rejected</option>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4e150f034db9bd45fe1495cb5234d541)): ?>
<?php $attributes = $__attributesOriginal4e150f034db9bd45fe1495cb5234d541; ?>
<?php unset($__attributesOriginal4e150f034db9bd45fe1495cb5234d541); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4e150f034db9bd45fe1495cb5234d541)): ?>
<?php $component = $__componentOriginal4e150f034db9bd45fe1495cb5234d541; ?>
<?php unset($__componentOriginal4e150f034db9bd45fe1495cb5234d541); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $attributes = $__attributesOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__attributesOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $component = $__componentOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__componentOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalcd518abb053461cdf447c22dc90a5514 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd518abb053461cdf447c22dc90a5514 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.group','data' => ['class' => 'w-full lg:w-6/12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full lg:w-6/12']); ?>
        <?php if (isset($component)) { $__componentOriginal4e150f034db9bd45fe1495cb5234d541 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4e150f034db9bd45fe1495cb5234d541 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.select','data' => ['name' => 'loan_type_id','label' => 'Loan Type','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'loan_type_id','label' => 'Loan Type','required' => true]); ?>
            <?php $selected = old('loan_type_id', ($editing ? $loanApplications->loan_type_id : '')) ?>
            <option disabled <?php echo e(empty($selected) ? 'selected' : ''); ?>>Please select the Loan Type</option>
            <?php $__currentLoopData = $loanTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value); ?>" <?php echo e($selected == $value ? 'selected' : ''); ?> ><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4e150f034db9bd45fe1495cb5234d541)): ?>
<?php $attributes = $__attributesOriginal4e150f034db9bd45fe1495cb5234d541; ?>
<?php unset($__attributesOriginal4e150f034db9bd45fe1495cb5234d541); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4e150f034db9bd45fe1495cb5234d541)): ?>
<?php $component = $__componentOriginal4e150f034db9bd45fe1495cb5234d541; ?>
<?php unset($__componentOriginal4e150f034db9bd45fe1495cb5234d541); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $attributes = $__attributesOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__attributesOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $component = $__componentOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__componentOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalcd518abb053461cdf447c22dc90a5514 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd518abb053461cdf447c22dc90a5514 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.group','data' => ['class' => 'w-full lg:w-6/12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full lg:w-6/12']); ?>
        <?php if (isset($component)) { $__componentOriginal4e150f034db9bd45fe1495cb5234d541 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4e150f034db9bd45fe1495cb5234d541 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.select','data' => ['name' => 'bank_id','label' => 'Bank','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'bank_id','label' => 'Bank','required' => true]); ?>
            <?php $selected = old('bank_id', ($editing ? $loanApplications->bank_id : '')) ?>
            <option disabled <?php echo e(empty($selected) ? 'selected' : ''); ?>>Please select the Bank</option>
            <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value); ?>" <?php echo e($selected == $value ? 'selected' : ''); ?> ><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4e150f034db9bd45fe1495cb5234d541)): ?>
<?php $attributes = $__attributesOriginal4e150f034db9bd45fe1495cb5234d541; ?>
<?php unset($__attributesOriginal4e150f034db9bd45fe1495cb5234d541); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4e150f034db9bd45fe1495cb5234d541)): ?>
<?php $component = $__componentOriginal4e150f034db9bd45fe1495cb5234d541; ?>
<?php unset($__componentOriginal4e150f034db9bd45fe1495cb5234d541); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $attributes = $__attributesOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__attributesOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $component = $__componentOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__componentOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalcd518abb053461cdf447c22dc90a5514 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd518abb053461cdf447c22dc90a5514 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.group','data' => ['class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full']); ?>
        <?php if (isset($component)) { $__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.text','data' => ['name' => 'reason_of_rejection','label' => 'Reason Of Rejection','value' => old('reason_of_rejection', ($editing ? $loanApplications->reason_of_rejection : '')),'placeholder' => 'Leave it empty while file new loan application']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'reason_of_rejection','label' => 'Reason Of Rejection','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('reason_of_rejection', ($editing ? $loanApplications->reason_of_rejection : ''))),'placeholder' => 'Leave it empty while file new loan application']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47)): ?>
<?php $attributes = $__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47; ?>
<?php unset($__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47)): ?>
<?php $component = $__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47; ?>
<?php unset($__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $attributes = $__attributesOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__attributesOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $component = $__componentOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__componentOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>
</div>
<?php /**PATH D:\RNFINTECH\New folder (8)\rnfintech\resources\views/app/all_loan_applications/form-inputs.blade.php ENDPATH**/ ?>