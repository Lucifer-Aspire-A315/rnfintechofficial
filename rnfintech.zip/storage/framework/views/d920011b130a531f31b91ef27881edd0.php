<?php $editing = isset($role) ?>

<div class="flex flex-wrap">
    <?php if (isset($component)) { $__componentOriginalcd518abb053461cdf447c22dc90a5514 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd518abb053461cdf447c22dc90a5514 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.group','data' => ['class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full']); ?>
        <?php if (isset($component)) { $__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.text','data' => ['name' => 'name','label' => 'Name','value' => old('name', ($editing ? $role->name : ''))]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'name','label' => 'Name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('name', ($editing ? $role->name : '')))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47)): ?>
<?php $attributes = $__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47; ?>
<?php unset($__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47)): ?>
<?php $component = $__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47; ?>
<?php unset($__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $attributes = $__attributesOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__attributesOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $component = $__componentOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__componentOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>

    <div class="px-4 my-4">
        <h4 class="font-bold text-lg text-gray-700">
            Assign <?php echo app('translator')->get('crud.permissions.name'); ?>
        </h4>

        <div class="py-2">
            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <?php if (isset($component)) { $__componentOriginal9068a82e0ddc3a935df0ee0cbd953fc3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9068a82e0ddc3a935df0ee0cbd953fc3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.checkbox','data' => ['id' => 'permission'.e($permission->id).'','name' => 'permissions[]','label' => ''.e(ucfirst($permission->name)).'','value' => ''.e($permission->id).'','checked' => isset($role) ? $role->hasPermissionTo($permission) : false,'addHiddenValue' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'permission'.e($permission->id).'','name' => 'permissions[]','label' => ''.e(ucfirst($permission->name)).'','value' => ''.e($permission->id).'','checked' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(isset($role) ? $role->hasPermissionTo($permission) : false),'add-hidden-value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9068a82e0ddc3a935df0ee0cbd953fc3)): ?>
<?php $attributes = $__attributesOriginal9068a82e0ddc3a935df0ee0cbd953fc3; ?>
<?php unset($__attributesOriginal9068a82e0ddc3a935df0ee0cbd953fc3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9068a82e0ddc3a935df0ee0cbd953fc3)): ?>
<?php $component = $__componentOriginal9068a82e0ddc3a935df0ee0cbd953fc3; ?>
<?php unset($__componentOriginal9068a82e0ddc3a935df0ee0cbd953fc3); ?>
<?php endif; ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH D:\RNFINTECH\New folder (8)\rnfintech\resources\views/app/roles/form-inputs.blade.php ENDPATH**/ ?>