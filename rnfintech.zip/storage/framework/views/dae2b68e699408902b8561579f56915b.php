<?php $editing = isset($user) ?>

<div class="flex flex-wrap">
    <?php if (isset($component)) { $__componentOriginalcd518abb053461cdf447c22dc90a5514 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd518abb053461cdf447c22dc90a5514 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.group','data' => ['class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full']); ?>
        <?php if (isset($component)) { $__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.text','data' => ['name' => 'name','label' => 'Name','value' => old('name', ($editing ? $user->name : '')),'maxlength' => '255','placeholder' => 'Name','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'name','label' => 'Name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('name', ($editing ? $user->name : ''))),'maxlength' => '255','placeholder' => 'Name','required' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47)): ?>
<?php $attributes = $__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47; ?>
<?php unset($__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47)): ?>
<?php $component = $__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47; ?>
<?php unset($__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $attributes = $__attributesOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__attributesOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $component = $__componentOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__componentOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalcd518abb053461cdf447c22dc90a5514 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd518abb053461cdf447c22dc90a5514 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.group','data' => ['class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full']); ?>
        <?php if (isset($component)) { $__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.text','data' => ['name' => 'phone','label' => 'Phone','value' => old('phone', ($editing ? $user->phone : '')),'maxlength' => '255','placeholder' => 'Phone','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'phone','label' => 'Phone','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('phone', ($editing ? $user->phone : ''))),'maxlength' => '255','placeholder' => 'Phone','required' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47)): ?>
<?php $attributes = $__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47; ?>
<?php unset($__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47)): ?>
<?php $component = $__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47; ?>
<?php unset($__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $attributes = $__attributesOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__attributesOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $component = $__componentOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__componentOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalcd518abb053461cdf447c22dc90a5514 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd518abb053461cdf447c22dc90a5514 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.group','data' => ['class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full']); ?>
        <?php if (isset($component)) { $__componentOriginal1610a9a93ae3859bddc037b06d326612 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1610a9a93ae3859bddc037b06d326612 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.email','data' => ['name' => 'email','label' => 'Email','value' => old('email', ($editing ? $user->email : '')),'maxlength' => '255','placeholder' => 'Email','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.email'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'email','label' => 'Email','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('email', ($editing ? $user->email : ''))),'maxlength' => '255','placeholder' => 'Email','required' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1610a9a93ae3859bddc037b06d326612)): ?>
<?php $attributes = $__attributesOriginal1610a9a93ae3859bddc037b06d326612; ?>
<?php unset($__attributesOriginal1610a9a93ae3859bddc037b06d326612); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1610a9a93ae3859bddc037b06d326612)): ?>
<?php $component = $__componentOriginal1610a9a93ae3859bddc037b06d326612; ?>
<?php unset($__componentOriginal1610a9a93ae3859bddc037b06d326612); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $attributes = $__attributesOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__attributesOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $component = $__componentOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__componentOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalcd518abb053461cdf447c22dc90a5514 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd518abb053461cdf447c22dc90a5514 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.group','data' => ['class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full']); ?>
        <?php if (isset($component)) { $__componentOriginalc2ebe5a42e860f2e11b7caba8b7e3cb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2ebe5a42e860f2e11b7caba8b7e3cb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.password','data' => ['name' => 'password','label' => 'Password','maxlength' => '255','placeholder' => 'Password','required' => !$editing]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.password'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'password','label' => 'Password','maxlength' => '255','placeholder' => 'Password','required' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(!$editing)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2ebe5a42e860f2e11b7caba8b7e3cb9)): ?>
<?php $attributes = $__attributesOriginalc2ebe5a42e860f2e11b7caba8b7e3cb9; ?>
<?php unset($__attributesOriginalc2ebe5a42e860f2e11b7caba8b7e3cb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2ebe5a42e860f2e11b7caba8b7e3cb9)): ?>
<?php $component = $__componentOriginalc2ebe5a42e860f2e11b7caba8b7e3cb9; ?>
<?php unset($__componentOriginalc2ebe5a42e860f2e11b7caba8b7e3cb9); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $attributes = $__attributesOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__attributesOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $component = $__componentOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__componentOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalcd518abb053461cdf447c22dc90a5514 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd518abb053461cdf447c22dc90a5514 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.group','data' => ['class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full']); ?>
        <?php if (isset($component)) { $__componentOriginal4e150f034db9bd45fe1495cb5234d541 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4e150f034db9bd45fe1495cb5234d541 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.select','data' => ['name' => 'role','label' => 'Role']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'role','label' => 'Role']); ?>
            <?php $selected = old('role', ($editing ? $user->role : '')) ?>
            <option value="customer" <?php echo e($selected == 'customer' ? 'selected' : ''); ?> >Customer</option>
            <option value="staff" <?php echo e($selected == 'staff' ? 'selected' : ''); ?> >Staff</option>
            <option value="agent" <?php echo e($selected == 'agent' ? 'selected' : ''); ?> >Agent</option>
            <option value="admin" <?php echo e($selected == 'admin' ? 'selected' : ''); ?> >Admin</option>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4e150f034db9bd45fe1495cb5234d541)): ?>
<?php $attributes = $__attributesOriginal4e150f034db9bd45fe1495cb5234d541; ?>
<?php unset($__attributesOriginal4e150f034db9bd45fe1495cb5234d541); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4e150f034db9bd45fe1495cb5234d541)): ?>
<?php $component = $__componentOriginal4e150f034db9bd45fe1495cb5234d541; ?>
<?php unset($__componentOriginal4e150f034db9bd45fe1495cb5234d541); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $attributes = $__attributesOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__attributesOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd518abb053461cdf447c22dc90a5514)): ?>
<?php $component = $__componentOriginalcd518abb053461cdf447c22dc90a5514; ?>
<?php unset($__componentOriginalcd518abb053461cdf447c22dc90a5514); ?>
<?php endif; ?>

    <div class="px-4 my-4">
        <h4 class="font-bold text-lg text-gray-700">
            Assign <?php echo app('translator')->get('crud.roles.name'); ?>
        </h4>

        <div class="py-2">
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <?php if (isset($component)) { $__componentOriginal9068a82e0ddc3a935df0ee0cbd953fc3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9068a82e0ddc3a935df0ee0cbd953fc3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.checkbox','data' => ['id' => 'role'.e($role->id).'','name' => 'roles[]','label' => ''.e(ucfirst($role->name)).'','value' => ''.e($role->id).'','checked' => isset($user) ? $user->hasRole($role) : false,'addHiddenValue' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'role'.e($role->id).'','name' => 'roles[]','label' => ''.e(ucfirst($role->name)).'','value' => ''.e($role->id).'','checked' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(isset($user) ? $user->hasRole($role) : false),'add-hidden-value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9068a82e0ddc3a935df0ee0cbd953fc3)): ?>
<?php $attributes = $__attributesOriginal9068a82e0ddc3a935df0ee0cbd953fc3; ?>
<?php unset($__attributesOriginal9068a82e0ddc3a935df0ee0cbd953fc3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9068a82e0ddc3a935df0ee0cbd953fc3)): ?>
<?php $component = $__componentOriginal9068a82e0ddc3a935df0ee0cbd953fc3; ?>
<?php unset($__componentOriginal9068a82e0ddc3a935df0ee0cbd953fc3); ?>
<?php endif; ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH D:\RNFINTECH\New folder (8)\rnfintech\resources\views/app/users/form-inputs.blade.php ENDPATH**/ ?>