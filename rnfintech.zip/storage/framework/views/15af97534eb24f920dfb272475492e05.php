<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo app('translator')->get('crud.loan_types.index_title'); ?>
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <?php if (isset($component)) { $__componentOriginal3673cea8c776183c9b825c8a8cd23921 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3673cea8c776183c9b825c8a8cd23921 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.partials.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('partials.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <div class="mb-5 mt-4">
                    <div class="flex flex-wrap justify-between">
                        <div class="md:w-1/2">
                            <form>
                                <div class="flex items-center w-full">
                                    <?php if (isset($component)) { $__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.text','data' => ['name' => 'search','value' => ''.e($search ?? '').'','placeholder' => ''.e(__('crud.common.search')).'','autocomplete' => 'off']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'search','value' => ''.e($search ?? '').'','placeholder' => ''.e(__('crud.common.search')).'','autocomplete' => 'off']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47)): ?>
<?php $attributes = $__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47; ?>
<?php unset($__attributesOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47)): ?>
<?php $component = $__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47; ?>
<?php unset($__componentOriginalb2bc0c9fd3d831bfef9cc03a1d4ebe47); ?>
<?php endif; ?>

                                    <div class="ml-1">
                                        <button
                                            type="submit"
                                            class="button button-primary"
                                        >
                                            <i class="icon ion-md-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="md:w-1/2 text-right">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\LoanType::class)): ?>
                            <a
                                href="<?php echo e(route('loan-types.create')); ?>"
                                class="button button-primary"
                            >
                                <i class="mr-1 icon ion-md-add"></i>
                                <?php echo app('translator')->get('crud.common.create'); ?>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="block w-full overflow-auto scrolling-touch">
                    <table class="w-full max-w-full mb-4 bg-transparent">
                        <thead class="text-gray-700">
                            <tr>
                                <th class="px-4 py-3 text-left">
                                    <?php echo app('translator')->get('crud.loan_types.inputs.name'); ?>
                                </th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-600">
                            <?php $__empty_1 = true; $__currentLoopData = $loanTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loanType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-3 text-left">
                                    <?php echo e($loanType->name ?? '-'); ?>

                                </td>
                                <td
                                    class="px-4 py-3 text-center"
                                    style="width: 134px;"
                                >
                                    <div
                                        role="group"
                                        aria-label="Row Actions"
                                        class="
                                            relative
                                            inline-flex
                                            align-middle
                                        "
                                    >
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $loanType)): ?>
                                        <a
                                            href="<?php echo e(route('loan-types.edit', $loanType)); ?>"
                                            class="mr-1"
                                        >
                                            <button
                                                type="button"
                                                class="button"
                                            >
                                                <i
                                                    class="icon ion-md-create"
                                                ></i>
                                            </button>
                                        </a>
                                        <?php endif; ?> <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', $loanType)): ?>
                                        <a
                                            href="<?php echo e(route('loan-types.show', $loanType)); ?>"
                                            class="mr-1"
                                        >
                                            <button
                                                type="button"
                                                class="button"
                                            >
                                                <i class="icon ion-md-eye"></i>
                                            </button>
                                        </a>
                                        <?php endif; ?> <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $loanType)): ?>
                                        <form
                                            action="<?php echo e(route('loan-types.destroy', $loanType)); ?>"
                                            method="POST"
                                            onsubmit="return confirm('<?php echo e(__('crud.common.are_you_sure')); ?>')"
                                        >
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button
                                                type="submit"
                                                class="button"
                                            >
                                                <i
                                                    class="
                                                        icon
                                                        ion-md-trash
                                                        text-red-600
                                                    "
                                                ></i>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="2">
                                    <?php echo app('translator')->get('crud.common.no_items_found'); ?>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="2">
                                    <div class="mt-10 px-4">
                                        <?php echo $loanTypes->render(); ?>

                                    </div>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3673cea8c776183c9b825c8a8cd23921)): ?>
<?php $attributes = $__attributesOriginal3673cea8c776183c9b825c8a8cd23921; ?>
<?php unset($__attributesOriginal3673cea8c776183c9b825c8a8cd23921); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3673cea8c776183c9b825c8a8cd23921)): ?>
<?php $component = $__componentOriginal3673cea8c776183c9b825c8a8cd23921; ?>
<?php unset($__componentOriginal3673cea8c776183c9b825c8a8cd23921); ?>
<?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\RNFINTECH\New folder (8)\rnfintech\resources\views/app/loan_types/index.blade.php ENDPATH**/ ?>