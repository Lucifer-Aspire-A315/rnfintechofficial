<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'bodyClasses' => 'flex-auto p-6',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'bodyClasses' => 'flex-auto p-6',
]); ?>
<?php foreach (array_filter(([
    'bodyClasses' => 'flex-auto p-6',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div <?php echo e($attributes->merge(['class' => 'relative flex flex-col rounded-lg bg-white break-words shadow-xl'])); ?>>
    <div class="<?php echo e($bodyClasses); ?>">
        
        <?php if(isset($title)): ?>
        <h4 class="text-lg font-bold mb-3">
            <?php echo e($title); ?>

        </h4>
        <?php endif; ?>

        <?php if(isset($subtitle)): ?>
        <h5 class="text-gray-600 text-sm">
            <?php echo e($subtitle); ?>

        </h5>
        <?php endif; ?>

        <?php echo e($slot); ?>

    </div>
</div><?php /**PATH D:\RNFINTECH\New folder (8)\rnfintech\resources\views/components/partials/card.blade.php ENDPATH**/ ?>