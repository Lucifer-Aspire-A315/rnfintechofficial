<label class="<?php echo e(($required ?? false) ? 'label label-required font-medium text-gray-700' : 'label font-medium text-gray-700'); ?>" for="<?php echo e($name); ?>">
    <?php echo e($label); ?>

</label><?php /**PATH D:\RNFINTECH\New folder (8)\rnfintech\resources\views/components/inputs/partials/label.blade.php ENDPATH**/ ?>